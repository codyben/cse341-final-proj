cd cob322;
javac *.java;